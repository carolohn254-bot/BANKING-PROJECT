# Real-Time Mobile Banking Account Balance Notification System

PHP + MySQL system built from the project documentation (Caroline John, DIT-01-0349/2025).
Customers make deposits, withdrawals and transfers; the balance is updated in the same database
transaction and an SMS/push notification with the new balance is sent immediately. A unique key stops
duplicate notifications, every delivery status is stored, and administrators can retry failures,
handle complaints, and read reports and the audit log.

## 1. Install on the computer (XAMPP)

1. Install XAMPP and start **Apache** and **MySQL** in the XAMPP Control Panel.
2. Copy this whole folder to `C:\xampp\htdocs\` so you have `C:\xampp\htdocs\bankalert\`
   (the folder name does not matter; the web address just follows it).
3. Create the database and the simulated starting data, **either**:
   - open `http://localhost/bankalert/install.php` in the browser (works once, then locks itself), **or**
   - in the XAMPP Shell: `cd C:\xampp\htdocs\bankalert` then `php install.php`
4. Open `http://localhost/bankalert/` and log in.

| Role | Username | Password / PIN |
| --- | --- | --- |
| Administrator | `admin` | `Admin@123` |
| Customer | `jane` | `Pass@1234` |
| Customer | `peter` | `Pass@1234` |
| Customer | `amina` | `Pass@1234` |

The customer password is also the **PIN** used to confirm each transaction. Change these after installing
(administrator > Customers > Edit sets a new password/PIN).

## 2. Open it from a phone, tablet or another computer

The pages are mobile-friendly and the links adjust to whatever address you use, so no code change is needed.

1. Connect the phone/other device to the **same Wi-Fi** as the computer running XAMPP
   (or switch on the computer's mobile hotspot and join it from the phone).
2. Find the computer's IP address: double-click `find-my-ip.bat`, or run `ipconfig` and read the
   **IPv4 Address** (for example `192.168.1.23`).
3. Allow Apache through the Windows firewall. Open **Command Prompt as Administrator** and run:
   `netsh advfirewall firewall add rule name="XAMPP Apache" dir=in action=allow protocol=TCP localport=80`
4. On the other device, open `http://192.168.1.23/bankalert/` (use your own IP and folder name).

If it does not load: confirm Apache shows green in XAMPP, both devices are on the same network, the
network is not a "guest" Wi-Fi that isolates devices, and that you typed `http://` (not `https://`).
The IP can change when you reconnect to Wi-Fi; run `find-my-ip.bat` again.

**Outside your network / for a demo link.** Tools such as Cloudflare Tunnel or ngrok can give the local site a
temporary public address (`ngrok http 80`). For permanent hosting, upload the folder to any PHP 7.4+/MySQL
hosting, edit `config/database.php` with the host's database details, and run `install.php` once.

## 3. How to test the main features

- **Real-time notification:** log in as `jane`, make a deposit, and watch the dashboard: the balance and a
  "New notification" banner update without refreshing. Open **Notifications** to see the message and status.
  In simulator mode the SMS text is also written to `storage/sms_outbox.log`.
- **Two devices at once:** log in as `jane` on the laptop and `peter` on the phone, transfer from Jane to
  Peter's account number (shown on his dashboard as `****0002`; full number `1000000002`) and watch both sides.
- **Duplicate prevention:** double-click Confirm, or refresh after submitting; only one transaction and one
  notification are created.
- **Failure and retry:** as admin open **Delivery monitor** and switch the *simulated gateway outage* ON, make a
  transaction as a customer (status becomes *Failed*), switch the outage OFF and press **Retry**.
- **Complaints, customers, reports, audit log:** administrator menu.
- **Automated checks:** `php tests/run_tests.php` (uses the same functions as the website).

## 4. Real SMS (optional)

Edit `config/database.php`: set `SMS_MODE` to `'africastalking'`, and fill `AT_USERNAME` (`sandbox` for testing)
and `AT_API_KEY`. PHP's cURL extension must be enabled (it is in XAMPP).

## 5. Folder map

| Path | Purpose |
| --- | --- |
| `index.php`, `logout.php` | Login (customers and administrators) and logout |
| `config/database.php` | Database, SMS gateway and application settings |
| `includes/auth.php` | Sessions, roles, inactivity timeout, live status check |
| `includes/functions.php` | Validation, reference generation, CSRF, audit logging |
| `includes/transaction.php` | Transaction module: validation, PIN, row locking, commit/rollback |
| `includes/notify.php` | Notification module: duplicate check, compose, send, save status, safe retry |
| `includes/sms.php` | SMS simulator / Africa's Talking, outage switch |
| `includes/layout.php` | Shared header, menus, footer |
| `customer/` | Dashboard, make transaction, history, notifications, settings, complaints |
| `admin/` | Dashboard, customers, transactions, delivery monitor, complaints, reports and audit log |
| `api/balance.php` | Live balance and latest notification for the dashboard |
| `assets/` | Stylesheet and JavaScript |
| `sql/schema.sql` | Six tables with the unique key on `notifications.transaction_id` |
| `install.php`, `tests/` | Installer and automated tests (delete `tests/` and `install.php` for a release copy) |
| `storage/` | SMS outbox log, outage switch, install lock (blocked from the web by `.htaccess`) |

## 6. Release checklist (as in section 3.9.2 of the documentation)

Remove `tests/`; keep `DEBUG` as `false`; time zone is already East Africa Time; keep SMS keys only in
`config/database.php`; change the starting passwords; on a real server also use HTTPS.

## Troubleshooting

- **"The database is not ready"**: run `install.php`; make sure MySQL is started.
- **Blank page**: set `DEBUG` to `true` in `config/database.php` temporarily, or read `C:\xampp\apache\logs\error.log`.
- **Port 80 busy**: change Apache's port in XAMPP and add it to the address, e.g. `http://192.168.1.23:8080/bankalert/`
  (the firewall rule must use the same port).
