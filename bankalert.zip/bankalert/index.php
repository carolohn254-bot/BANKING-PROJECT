<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';
start_secure_session();

if (!empty($_SESSION['user_id'])) {
    redirect(($_SESSION['role'] ?? '') === 'admin' ? 'admin/dashboard.php' : 'customer/dashboard.php');
}
$error = '';
try {
    db();
} catch (Throwable $e) {
    $error = 'The database is not ready. Run install.php first (see README.md).';
}
if ($error === '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? '');
    $p = (string)($_POST['password'] ?? '');
    if (!csrf_check()) {
        $error = 'Session expired. Please try again.';
    } elseif ($u === '' || $p === '') {
        $error = 'Enter your username and password / PIN.';
    } else {
        [$ok, $msg] = login_user($u, $p);
        if ($ok) { redirect($_SESSION['role'] === 'admin' ? 'admin/dashboard.php' : 'customer/dashboard.php'); }
        $error = $msg;
    }
}
page_header('Login');
if ($error) { echo '<div class="alert error">' . h($error) . '</div>'; }
?>
<form method="post" class="card narrow" autocomplete="off">
  <?= csrf_field() ?>
  <label>Username
    <input type="text" name="username" required autofocus value="<?= h($_POST['username'] ?? '') ?>">
  </label>
  <label>Password / PIN
    <input type="password" name="password" required>
  </label>
  <button class="btn" type="submit">Log in</button>
  <p class="muted">Customers and administrators use this same page.</p>
</form>
<?php page_footer();
