<?php
/**
 * Installer. Creates the database from sql/schema.sql and adds simulated starting data.
 *   Command line:  php install.php        (or from the XAMPP shell)
 *   Browser:       http://localhost/bankalert/install.php   (works once; locks itself afterwards)
 */
require_once __DIR__ . '/config/database.php';

$cli  = PHP_SAPI === 'cli';
$lock = __DIR__ . '/storage/installed.lock';
function say(string $m, bool $cli): void { echo $cli ? $m . PHP_EOL : '<p>' . htmlspecialchars($m) . '</p>'; }

if (!$cli) {
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;max-width:640px;margin:2rem auto;padding:0 1rem"><h2>System installer</h2>';
    if (is_file($lock)) { say('Already installed. Delete storage/installed.lock only if you want to install again.', false); exit; }
}

try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $pdo->exec('USE `' . DB_NAME . '`');

    $sql = file_get_contents(__DIR__ . '/sql/schema.sql');
    $sql = preg_replace('/^--.*$/m', '', $sql);                                   // drop comment lines
    $sql = preg_replace('/^(CREATE DATABASE|USE) .*;$/mi', '', $sql);            // database already selected above
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $statement) { $pdo->exec($statement); }
    say('Tables created.', $cli);

    if ((int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() === 0) {
        $ins = $pdo->prepare('INSERT INTO users (username, full_name, phone_number, password_hash, role, notify_preference) VALUES (?, ?, ?, ?, ?, ?)');
        $acc = $pdo->prepare('INSERT INTO accounts (user_id, account_number, balance) VALUES (?, ?, ?)');
        $seed = [
            ['admin',   'Bank Administrator', '+254700000000', 'Admin@123', 'admin',    'sms', null,         null],
            ['jane',    'Jane Wanjiku',       '+254711000001', 'Pass@1234', 'customer', 'sms', '1000000001', 25000.00],
            ['peter',   'Peter Otieno',       '+254722000002', 'Pass@1234', 'customer', 'both', '1000000002', 18500.50],
            ['amina',   'Amina Hassan',       '+254733000003', 'Pass@1234', 'customer', 'push', '1000000003', 52000.00],
        ];
        foreach ($seed as [$u, $n, $p, $pw, $role, $pref, $an, $bal]) {
            $ins->execute([$u, $n, $p, password_hash($pw, PASSWORD_DEFAULT), $role, $pref]);
            if ($an) { $acc->execute([$pdo->lastInsertId(), $an, $bal]); }
        }
        say('Simulated starting data added (1 administrator, 3 customers).', $cli);
    } else {
        say('Users already exist, starting data not added again.', $cli);
    }
    @file_put_contents($lock, date('c'));
    say('Done. Log in with:  admin / Admin@123   or   jane / Pass@1234   (peter, amina use the same PIN).', $cli);
    if (!$cli) { echo '<p><a href="index.php">Open the login page</a></p>'; }
} catch (Throwable $e) {
    say('Installation failed: ' . $e->getMessage(), $cli);
    say('Check that MySQL is running in the XAMPP control panel and that config/database.php is correct.', $cli);
    exit(1);
}
