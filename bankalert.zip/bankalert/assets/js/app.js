// Shared behaviour for all pages.
(function () {
  // 1. Disable a submit button after the first click so a double click cannot submit twice.
  document.querySelectorAll('form').forEach(function (f) {
    f.addEventListener('submit', function () {
      var b = f.querySelector('button[data-once]');
      if (b) { setTimeout(function () { b.disabled = true; b.textContent = 'Processing...'; }, 0); }
    });
  });

  // 2. Show the receiving-account field only for transfers.
  var type = document.getElementById('type'), wrap = document.getElementById('to-wrap');
  if (type && wrap) {
    var toggle = function () { wrap.style.display = type.value === 'transfer' ? '' : 'none'; };
    type.addEventListener('change', toggle); toggle();
  }

  // 3. Dashboard: refresh the balance and show new notifications without reloading the page.
  var bal = document.getElementById('bal');
  if (bal && bal.dataset.poll) {
    var live = document.getElementById('live'), lastId = null;
    var poll = function () {
      fetch(bal.dataset.poll, { credentials: 'same-origin', cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (d) {
          if (!d) { return; }
          bal.textContent = d.balance;
          if (d.notification) {
            if (lastId !== null && d.notification.notification_id !== lastId && live) {
              live.hidden = false; live.textContent = 'New notification: ' + d.notification.message;
            }
            lastId = d.notification.notification_id;
          } else if (lastId === null) { lastId = 0; }
        }).catch(function () {});
    };
    poll(); setInterval(poll, 5000);
  }
})();
