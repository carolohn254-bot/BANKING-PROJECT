@echo off
echo.
echo  Addresses of this computer (use the IPv4 one that starts with 192.168 or 10. or 172.):
echo.
ipconfig | findstr /i "IPv4"
echo.
echo  On a phone or another computer on the SAME Wi-Fi, open:  http://YOUR-IPv4-ADDRESS/bankalert/
echo.
pause
