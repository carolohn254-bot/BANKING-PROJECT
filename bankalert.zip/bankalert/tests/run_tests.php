<?php
/**
 * Automated checks. Run from the command line:  php tests/run_tests.php
 * Creates its own test customers, runs the checks, then removes nothing from the audit trail (transactions remain as evidence).
 * Delete the tests/ folder from the release copy before deployment.
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Run this script from the command line.'); }
require_once __DIR__ . '/../includes/transaction.php';
require_once __DIR__ . "/../includes/sms.php";

$pdo = db(); $pass = 0; $fail = 0;
function check(string $name, bool $ok): void { global $pass, $fail; $ok ? $pass++ : $fail++; echo ($ok ? '[PASS] ' : '[FAIL] ') . $name . PHP_EOL; }
function mk(PDO $pdo, string $name, float $bal, string $pref = 'sms'): array
{
    $u = $name . random_int(1000, 9999);
    $pdo->prepare("INSERT INTO users (username, full_name, phone_number, password_hash, role, notify_preference) VALUES (?, ?, '+254711999999', ?, 'customer', ?)")
        ->execute([$u, $name, password_hash('1234', PASSWORD_DEFAULT), $pref]);
    $id = (int)$pdo->lastInsertId();
    $an = '9' . str_pad((string)random_int(0, 999999999), 9, '0', STR_PAD_LEFT);
    $pdo->prepare('INSERT INTO accounts (user_id, account_number, balance) VALUES (?, ?, ?)')->execute([$id, $an, $bal]);
    $st = $pdo->prepare('SELECT * FROM users WHERE user_id = ?'); $st->execute([$id]);
    return [$st->fetch(), $an];
}
function bal(PDO $pdo, int $uid): string { $s = $pdo->prepare('SELECT balance FROM accounts WHERE user_id = ?'); $s->execute([$uid]); return $s->fetchColumn(); }
function cnt(PDO $pdo, string $sql, array $a = []): int { $s = $pdo->prepare($sql); $s->execute($a); return (int)$s->fetchColumn(); }

sms_set_outage(false);
[$A, $accA] = mk($pdo, 'TestA', 1000); [$B, $accB] = mk($pdo, 'TestB', 500);

// Unit tests
check('Amount parser accepts 1,250.50', parse_amount('1,250.50') === 125050);
check('Amount parser rejects zero, negative and text', parse_amount('0') === null && parse_amount('-5') === null && parse_amount('abc') === null);
check('Phone normaliser converts 0712345678', normalise_phone('0712345678') === '+254712345678');
check('Phone normaliser rejects bad number', normalise_phone('12345') === null);
check('Reference has valid format', valid_ref(generate_ref()));

// Deposit
$r = process_transaction($pdo, $A, 'deposit', '200', '', generate_ref(), '1234');
check('Deposit succeeds and balance increases', $r['ok'] && bal($pdo, $A['user_id']) === '1200.00');
check('Deposit created exactly one notification, status sent', $r['notification'] === 'sent');
$tid = cnt($pdo, 'SELECT MAX(transaction_id) FROM transactions WHERE account_id = (SELECT account_id FROM accounts WHERE user_id = ?)', [$A['user_id']]);
check('Notification message shows the stored balance', cnt($pdo, "SELECT COUNT(*) FROM notifications WHERE transaction_id = ? AND message LIKE '%New balance KES 1,200.00%'", [$tid]) === 1);

// Withdrawal and validation
$r = process_transaction($pdo, $A, 'withdrawal', '100', '', generate_ref(), '1234');
check('Withdrawal succeeds', $r['ok'] && bal($pdo, $A['user_id']) === '1100.00');
$before = cnt($pdo, 'SELECT COUNT(*) FROM transactions');
$r = process_transaction($pdo, $A, 'withdrawal', '999999', '', generate_ref(), '1234');
check('Withdrawal above balance is rejected, nothing saved', !$r['ok'] && cnt($pdo, 'SELECT COUNT(*) FROM transactions') === $before);
$r = process_transaction($pdo, $A, 'deposit', '50', '', generate_ref(), 'wrong');
check('Wrong PIN is rejected', !$r['ok']);
foreach (['0', '-10', 'abc', ''] as $bad) {
    $r = process_transaction($pdo, $A, 'deposit', $bad, '', generate_ref(), '1234');
    check("Invalid amount '$bad' is rejected", !$r['ok']);
}
$exact = bal($pdo, $A['user_id']);
$r = process_transaction($pdo, $A, 'withdrawal', $exact, '', generate_ref(), '1234');
check('Withdrawal equal to the balance leaves zero', $r['ok'] && bal($pdo, $A['user_id']) === '0.00');
process_transaction($pdo, $A, 'deposit', '1000', '', generate_ref(), '1234');

// Duplicate submission
$ref = generate_ref(); $n0 = cnt($pdo, 'SELECT COUNT(*) FROM transactions');
$r1 = process_transaction($pdo, $A, 'deposit', '10', '', $ref, '1234');
$r2 = process_transaction($pdo, $A, 'deposit', '10', '', $ref, '1234');
check('Same reference submitted twice creates only one transaction', $r1['ok'] && !$r2['ok'] && cnt($pdo, 'SELECT COUNT(*) FROM transactions') === $n0 + 1);
$tid = cnt($pdo, 'SELECT transaction_id FROM transactions WHERE transaction_ref = ?', [$ref]);
check('Notify called again for same transaction sends nothing', notify_transaction($pdo, $tid) === 'duplicate');
$blocked = false;
try { $pdo->prepare("INSERT INTO notifications (transaction_id, message, channel) VALUES (?, 'x', 'SMS')")->execute([$tid]); }
catch (PDOException $e) { $blocked = ($e->errorInfo[1] === 1062); }
check('Database unique key rejects a second notification', $blocked);

// Transfers
$a0 = decimal_to_cents(bal($pdo, $A['user_id'])); $b0 = decimal_to_cents(bal($pdo, $B['user_id']));
$ref = generate_ref();
$r = process_transaction($pdo, $A, 'transfer', '300', $accB, $ref, '1234');
check('Transfer updates both balances', $r['ok'] && decimal_to_cents(bal($pdo, $A['user_id'])) === $a0 - 30000 && decimal_to_cents(bal($pdo, $B['user_id'])) === $b0 + 30000);
check('Both account holders get a notification', cnt($pdo, 'SELECT COUNT(*) FROM notifications n JOIN transactions t ON t.transaction_id = n.transaction_id WHERE t.transaction_ref IN (?, ?)', [$ref, $ref . 'R']) === 2);
$r = process_transaction($pdo, $A, 'transfer', '10', '9999999999', generate_ref(), '1234');
check('Transfer to unknown account is rejected', !$r['ok']);
$r = process_transaction($pdo, $A, 'transfer', '10', $accA, generate_ref(), '1234');
check('Transfer to own account is rejected', !$r['ok']);

// Gateway failure and retry
sms_set_outage(true);
$r = process_transaction($pdo, $A, 'deposit', '20', '', generate_ref(), '1234');
check('Gateway outage: transaction saved, notification failed', $r['ok'] && $r['notification'] === 'failed');
sms_set_outage(false);
$nid = cnt($pdo, "SELECT MAX(notification_id) FROM notifications WHERE status = 'failed'");
[$ok] = retry_notification($pdo, $nid, (int)$A['user_id']);
check('Retry after outage sends the message and counts the retry', $ok && cnt($pdo, "SELECT COUNT(*) FROM notifications WHERE notification_id = ? AND status='sent' AND retry_count = 1", [$nid]) === 1);
[$ok2] = retry_notification($pdo, $nid, (int)$A['user_id']);
check('Retry of an already sent notification is refused', !$ok2);

// Accuracy: the last balance_after equals the stored balance
$last = $pdo->prepare('SELECT balance_after FROM transactions WHERE account_id = (SELECT account_id FROM accounts WHERE user_id = ?) ORDER BY transaction_id DESC LIMIT 1');
$last->execute([$A['user_id']]);
check('Balance in the last record equals the stored balance', $last->fetchColumn() === bal($pdo, $A['user_id']));

echo PHP_EOL . "$pass passed, $fail failed." . PHP_EOL;
exit($fail ? 1 : 0);
