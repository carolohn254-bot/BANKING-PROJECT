<?php
/** Returns the customer's current balance and latest notification so the dashboard can refresh itself. */
require_once __DIR__ . '/../includes/auth.php';
$user = require_login(['customer']);
header('Content-Type: application/json');
header('Cache-Control: no-store');

$acc = customer_account((int)$user['user_id']);
$st = db()->prepare('SELECT n.notification_id, n.message, n.status, n.channel, n.sent_at
                     FROM notifications n JOIN transactions t ON t.transaction_id = n.transaction_id
                     WHERE t.account_id = ? ORDER BY n.notification_id DESC LIMIT 1');
$st->execute([$acc['account_id']]);
echo json_encode([
    'balance'      => money($acc['balance']),
    'notification' => $st->fetch() ?: null,
]);
