<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_login(['admin']);
$from = valid_date($_GET['from'] ?? null); $to = valid_date($_GET['to'] ?? null);
$q = trim($_GET['q'] ?? '');
$where = '1=1'; $args = [];
if ($from) { $where .= ' AND t.created_at >= ?'; $args[] = $from . ' 00:00:00'; }
if ($to)   { $where .= ' AND t.created_at <= ?'; $args[] = $to . ' 23:59:59'; }
if ($q !== '') { $where .= ' AND (t.transaction_ref LIKE ? OR a.account_number LIKE ? OR u.full_name LIKE ?)'; array_push($args, "%$q%", "%$q%", "%$q%"); }
$per = 15; $page = page_number();
$base = 'FROM transactions t JOIN accounts a ON a.account_id = t.account_id JOIN users u ON u.user_id = a.user_id
         LEFT JOIN notifications n ON n.transaction_id = t.transaction_id WHERE ' . $where;
$c = db()->prepare("SELECT COUNT(*) $base"); $c->execute($args); $total = (int)$c->fetchColumn();
$st = db()->prepare("SELECT t.*, a.account_number, u.full_name, n.status AS nstatus $base ORDER BY t.transaction_id DESC LIMIT $per OFFSET " . (($page - 1) * $per));
$st->execute($args); $rows = $st->fetchAll();

page_header('Monitor transactions', 'admin', 'transactions');
?>
<form method="get" class="card filters">
  <label>From <input type="date" name="from" value="<?= h($from) ?>"></label>
  <label>To <input type="date" name="to" value="<?= h($to) ?>"></label>
  <label>Account / reference / name <input name="q" value="<?= h($q) ?>"></label>
  <button class="btn" type="submit">Filter</button>
</form>
<div class="card"><div class="scroll"><table>
  <tr><th>Date</th><th>Reference</th><th>Customer</th><th>Account</th><th>Type</th><th class="r">Amount</th><th class="r">Balance after</th><th>Notification</th></tr>
  <?php foreach ($rows as $t): ?>
    <tr><td><?= h($t['created_at']) ?></td><td><?= h($t['transaction_ref']) ?></td><td><?= h($t['full_name']) ?></td><td><?= h($t['account_number']) ?></td>
      <td><?= h(ucfirst($t['type'])) ?> (<?= h($t['direction']) ?>)</td><td class="r"><?= h(money($t['amount'])) ?></td><td class="r"><?= h(money($t['balance_after'])) ?></td>
      <td><?= $t['nstatus'] ? status_badge($t['nstatus']) : '<span class="muted">none</span>' ?></td></tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="8" class="muted">No transactions found.</td></tr><?php endif; ?>
</table></div><?= pagination($total, $per, $page) ?></div>
<?php page_footer();
