<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/sms.php';
$admin = require_login(['admin']);
$pdo = db();
$one = fn(string $sql) => (int)$pdo->query($sql)->fetchColumn();

$customers = $one("SELECT COUNT(*) FROM users WHERE role='customer'");
$txToday   = $one("SELECT COUNT(*) FROM transactions WHERE DATE(created_at) = CURDATE()");
$sent      = $one("SELECT COUNT(*) FROM notifications WHERE status='sent'");
$failed    = $one("SELECT COUNT(*) FROM notifications WHERE status='failed'");
$pending   = $one("SELECT COUNT(*) FROM notifications WHERE status='pending'");
$open      = $one("SELECT COUNT(*) FROM complaints WHERE status<>'resolved'");
$max = max(1, $sent, $failed, $pending);
$fails = $pdo->query("SELECT n.notification_id, n.status, n.created_at, t.transaction_ref FROM notifications n
                      JOIN transactions t ON t.transaction_id = n.transaction_id WHERE n.status <> 'sent' ORDER BY n.notification_id DESC LIMIT 5")->fetchAll();

page_header('Administrator dashboard', 'admin', 'dashboard');
?>
<div class="stats">
  <div class="stat"><b><?= $customers ?></b>Customers</div>
  <div class="stat"><b><?= $txToday ?></b>Transactions today</div>
  <div class="stat ok"><b><?= $sent ?></b>Notifications sent</div>
  <div class="stat bad"><b><?= $failed ?></b>Failed</div>
  <div class="stat warn"><b><?= $pending ?></b>Pending</div>
  <div class="stat"><b><?= $open ?></b>Open complaints</div>
</div>
<div class="grid">
  <div class="card"><h2>Notification delivery</h2>
    <?php foreach (['Sent' => [$sent, 'ok'], 'Failed' => [$failed, 'bad'], 'Pending' => [$pending, 'warn']] as $label => [$n, $cls]): ?>
      <div class="bar"><span><?= $label ?> (<?= $n ?>)</span><i class="<?= $cls ?>" style="width:<?= round($n / $max * 100) ?>%"></i></div>
    <?php endforeach; ?>
    <p class="muted">SMS gateway mode: <b><?= h(SMS_MODE) ?></b><?= sms_outage_active() ? ' &middot; <span class="badge bad">Outage switch ON</span>' : '' ?></p>
  </div>
  <div class="card"><h2>Recent failures</h2>
    <?php foreach ($fails as $f): ?>
      <div class="note"><?= status_badge($f['status']) ?> <?= h($f['transaction_ref']) ?> <small><?= h($f['created_at']) ?></small></div>
    <?php endforeach; ?>
    <?php if (!$fails): ?><p class="muted">No failed or pending notifications.</p><?php endif; ?>
    <a class="btn small" href="<?= h(url('admin/delivery.php')) ?>">Open delivery monitor</a>
  </div>
</div>
<?php page_footer();
