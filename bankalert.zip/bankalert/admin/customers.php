<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
$admin = require_login(['admin']);
$pdo = db();
$error = '';

function new_account_number(PDO $pdo): string
{
    do {
        $n = '10' . str_pad((string)random_int(0, 99999999), 8, '0', STR_PAD_LEFT);
        $st = $pdo->prepare('SELECT 1 FROM accounts WHERE account_number = ?'); $st->execute([$n]);
    } while ($st->fetch());
    return $n;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if (!csrf_check()) { $error = 'Session expired. Please try again.'; }
    elseif ($action === 'add') {
        $username = trim($_POST['username'] ?? ''); $name = trim($_POST['full_name'] ?? '');
        $phone = normalise_phone((string)($_POST['phone'] ?? '')); $pass = (string)($_POST['password'] ?? '');
        if (!preg_match('/^[A-Za-z0-9._-]{3,50}$/', $username)) { $error = 'Username must be 3-50 letters, digits, dot, dash or underscore.'; }
        elseif ($name === '' || mb_strlen($name) > 100) { $error = 'Enter the full name.'; }
        elseif (!$phone) { $error = 'Enter a valid Kenyan mobile number.'; }
        elseif (strlen($pass) < 4) { $error = 'The password / PIN must have at least 4 characters.'; }
        else {
            try {
                $pdo->beginTransaction();
                $pdo->prepare("INSERT INTO users (username, full_name, phone_number, password_hash, role) VALUES (?, ?, ?, ?, 'customer')")
                    ->execute([$username, $name, $phone, password_hash($pass, PASSWORD_DEFAULT)]);
                $uid = (int)$pdo->lastInsertId();
                $pdo->prepare('INSERT INTO accounts (user_id, account_number, balance) VALUES (?, ?, 0)')->execute([$uid, new_account_number($pdo)]);
                $pdo->commit();
                audit((int)$admin['user_id'], 'customer_added', $username);
                flash('success', 'Customer added.'); redirect('admin/customers.php');
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) { $pdo->rollBack(); }
                $error = ($e->errorInfo[1] ?? 0) === 1062 ? 'That username already exists.' : 'Could not add the customer.';
            }
        }
    } elseif ($action === 'edit') {
        $uid = (int)($_POST['user_id'] ?? 0); $name = trim($_POST['full_name'] ?? '');
        $phone = normalise_phone((string)($_POST['phone'] ?? '')); $pass = (string)($_POST['password'] ?? '');
        if ($name === '' || !$phone) { $error = 'Enter a name and a valid Kenyan mobile number.'; }
        elseif ($pass !== '' && strlen($pass) < 4) { $error = 'The new password / PIN must have at least 4 characters.'; }
        else {
            $pdo->prepare("UPDATE users SET full_name = ?, phone_number = ? WHERE user_id = ? AND role = 'customer'")->execute([$name, $phone, $uid]);
            if ($pass !== '') { $pdo->prepare("UPDATE users SET password_hash = ? WHERE user_id = ? AND role = 'customer'")->execute([password_hash($pass, PASSWORD_DEFAULT), $uid]); }
            audit((int)$admin['user_id'], 'customer_edited', 'user ' . $uid);
            flash('success', 'Customer updated.'); redirect('admin/customers.php');
        }
    } elseif ($action === 'suspend' || $action === 'activate') {
        $uid = (int)($_POST['user_id'] ?? 0);
        $pdo->prepare("UPDATE users SET status = ? WHERE user_id = ? AND role = 'customer'")->execute([$action === 'suspend' ? 'suspended' : 'active', $uid]);
        audit((int)$admin['user_id'], 'customer_' . $action, 'user ' . $uid);
        flash('success', 'Customer ' . ($action === 'suspend' ? 'suspended' : 'activated') . '.'); redirect('admin/customers.php');
    }
}

$q = trim($_GET['q'] ?? '');
$sql = "SELECT u.*, a.account_number, a.balance FROM users u LEFT JOIN accounts a ON a.user_id = u.user_id WHERE u.role='customer'";
$args = [];
if ($q !== '') { $sql .= ' AND (u.username LIKE ? OR u.full_name LIKE ? OR a.account_number LIKE ? OR u.phone_number LIKE ?)'; $args = array_fill(0, 4, "%$q%"); }
$st = $pdo->prepare($sql . ' ORDER BY u.user_id DESC'); $st->execute($args);
$rows = $st->fetchAll();
$editId = (int)($_GET['edit'] ?? 0);

page_header('Manage customers', 'admin', 'customers');
if ($error) { echo '<div class="alert error">' . h($error) . '</div>'; }
?>
<form method="get" class="card filters"><label>Search <input type="text" name="q" value="<?= h($q) ?>" placeholder="name, username, account, phone"></label><button class="btn" type="submit">Search</button></form>
<div class="card"><div class="scroll"><table>
  <tr><th>Name</th><th>Username</th><th>Phone</th><th>Account</th><th class="r">Balance</th><th>Status</th><th>Actions</th></tr>
  <?php foreach ($rows as $r): ?>
    <tr><td><?= h($r['full_name']) ?></td><td><?= h($r['username']) ?></td><td><?= h($r['phone_number']) ?></td><td><?= h($r['account_number']) ?></td>
      <td class="r"><?= h(money($r['balance'])) ?></td><td><?= status_badge($r['status']) ?></td>
      <td class="acts"><a class="btn small" href="?edit=<?= (int)$r['user_id'] ?>">Edit</a>
        <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="user_id" value="<?= (int)$r['user_id'] ?>">
          <?php if ($r['status'] === 'active'): ?><button class="btn small danger" name="action" value="suspend">Suspend</button>
          <?php else: ?><button class="btn small" name="action" value="activate">Activate</button><?php endif; ?></form></td></tr>
    <?php if ($editId === (int)$r['user_id']): ?>
    <tr><td colspan="7"><form method="post" class="filters"><?= csrf_field() ?><input type="hidden" name="action" value="edit"><input type="hidden" name="user_id" value="<?= (int)$r['user_id'] ?>">
      <label>Full name <input name="full_name" value="<?= h($r['full_name']) ?>" required></label>
      <label>Phone <input name="phone" value="<?= h($r['phone_number']) ?>" required></label>
      <label>New password / PIN (optional) <input type="password" name="password"></label>
      <button class="btn small" type="submit">Save</button></form></td></tr>
    <?php endif; ?>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="7" class="muted">No customers found.</td></tr><?php endif; ?>
</table></div></div>
<form method="post" class="card narrow"><h2>Add customer</h2><?= csrf_field() ?><input type="hidden" name="action" value="add">
  <label>Username <input name="username" required></label>
  <label>Full name <input name="full_name" required></label>
  <label>Phone number <input name="phone" required placeholder="0712345678"></label>
  <label>Password / PIN <input type="password" name="password" required></label>
  <button class="btn" type="submit">Add customer and open account</button>
</form>
<?php page_footer();
