<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_login(['admin']);
$pdo = db();
$from = valid_date($_GET['from'] ?? null) ?? date('Y-m-01');
$to   = valid_date($_GET['to'] ?? null) ?? date('Y-m-d');
$a = [$from . ' 00:00:00', $to . ' 23:59:59'];

// Count each money movement once: deposits (credit), withdrawals and transfers (debit side only).
$tx = $pdo->prepare("SELECT type, COUNT(*) c, COALESCE(SUM(amount),0) s FROM transactions
                     WHERE created_at BETWEEN ? AND ? AND (type='deposit' OR direction='debit') GROUP BY type");
$tx->execute($a); $txRows = $tx->fetchAll();
$nt = $pdo->prepare('SELECT n.status, COUNT(*) c FROM notifications n WHERE n.created_at BETWEEN ? AND ? GROUP BY n.status');
$nt->execute($a); $ntRows = $nt->fetchAll();
$cp = $pdo->prepare('SELECT status, COUNT(*) c FROM complaints WHERE created_at BETWEEN ? AND ? GROUP BY status');
$cp->execute($a); $cpRows = $cp->fetchAll();

if (isset($_GET['export'])) {                                   // CSV export of the transactions in the period
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="report_' . $from . '_to_' . $to . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['created_at', 'reference', 'account', 'type', 'direction', 'amount', 'balance_after', 'notification_status']);
    $st = $pdo->prepare('SELECT t.created_at, t.transaction_ref, a.account_number, t.type, t.direction, t.amount, t.balance_after, n.status
        FROM transactions t JOIN accounts a ON a.account_id = t.account_id LEFT JOIN notifications n ON n.transaction_id = t.transaction_id
        WHERE t.created_at BETWEEN ? AND ? ORDER BY t.transaction_id');
    $st->execute($a);
    foreach ($st as $r) { fputcsv($out, array_values($r)); }
    exit;
}

$per = 20; $page = page_number();
$total = (int)$pdo->query('SELECT COUNT(*) FROM audit_logs')->fetchColumn();
$logs = $pdo->query('SELECT l.*, u.username FROM audit_logs l LEFT JOIN users u ON u.user_id = l.user_id
                     ORDER BY l.log_id DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per))->fetchAll();

page_header('Reports and audit log', 'admin', 'reports');
?>
<form method="get" class="card filters">
  <label>From <input type="date" name="from" value="<?= h($from) ?>"></label>
  <label>To <input type="date" name="to" value="<?= h($to) ?>"></label>
  <button class="btn" type="submit">Generate</button>
  <a class="btn ghost" href="?from=<?= h($from) ?>&to=<?= h($to) ?>&export=1">Export CSV</a>
</form>
<div class="grid">
  <div class="card"><h2>Transactions</h2><table><tr><th>Type</th><th class="r">Count</th><th class="r">Total (KES)</th></tr>
    <?php foreach ($txRows as $r): ?><tr><td><?= h(ucfirst($r['type'])) ?></td><td class="r"><?= (int)$r['c'] ?></td><td class="r"><?= h(money($r['s'])) ?></td></tr><?php endforeach; ?>
    <?php if (!$txRows): ?><tr><td colspan="3" class="muted">No transactions in this period.</td></tr><?php endif; ?></table></div>
  <div class="card"><h2>Notifications</h2><table><tr><th>Status</th><th class="r">Count</th></tr>
    <?php foreach ($ntRows as $r): ?><tr><td><?= status_badge($r['status']) ?></td><td class="r"><?= (int)$r['c'] ?></td></tr><?php endforeach; ?>
    <?php if (!$ntRows): ?><tr><td colspan="2" class="muted">None in this period.</td></tr><?php endif; ?></table>
    <h2>Complaints</h2><table><tr><th>Status</th><th class="r">Count</th></tr>
    <?php foreach ($cpRows as $r): ?><tr><td><?= status_badge($r['status']) ?></td><td class="r"><?= (int)$r['c'] ?></td></tr><?php endforeach; ?>
    <?php if (!$cpRows): ?><tr><td colspan="2" class="muted">None in this period.</td></tr><?php endif; ?></table></div>
</div>
<div class="card"><h2>Audit log</h2><div class="scroll"><table>
  <tr><th>Time</th><th>User</th><th>Action</th><th>Details</th></tr>
  <?php foreach ($logs as $l): ?><tr><td><?= h($l['created_at']) ?></td><td><?= h($l['username'] ?? '-') ?></td><td><?= h($l['action']) ?></td><td><?= h($l['details']) ?></td></tr><?php endforeach; ?>
</table></div><?= pagination($total, $per, $page) ?></div>
<?php page_footer();
