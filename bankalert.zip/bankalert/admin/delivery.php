<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/notify.php';
$admin = require_login(['admin']);
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_check()) {
    if (($_POST['action'] ?? '') === 'retry') {
        [$ok, $msg] = retry_notification($pdo, (int)($_POST['notification_id'] ?? 0), (int)$admin['user_id']);
        flash($ok ? 'success' : 'error', $msg);
    } elseif (($_POST['action'] ?? '') === 'outage' && SMS_MODE === 'simulator') {
        $on = ($_POST['state'] ?? '') === 'on';
        sms_set_outage($on);
        audit((int)$admin['user_id'], 'sms_outage_switch', $on ? 'ON' : 'OFF');
        flash('info', 'Simulated SMS gateway outage is now ' . ($on ? 'ON: new messages will fail.' : 'OFF.'));
    }
    redirect('admin/delivery.php' . (isset($_GET['status']) ? '?status=' . urlencode($_GET['status']) : ''));
}

$counts = ['sent' => 0, 'failed' => 0, 'pending' => 0];
foreach ($pdo->query('SELECT status, COUNT(*) c FROM notifications GROUP BY status')->fetchAll() as $r) { $counts[$r['status']] = (int)$r['c']; }
$status = in_array($_GET['status'] ?? '', ['sent', 'failed', 'pending'], true) ? $_GET['status'] : '';
$per = 15; $page = page_number();
$where = $status ? 'WHERE n.status = ?' : ''; $args = $status ? [$status] : [];
$c = $pdo->prepare("SELECT COUNT(*) FROM notifications n $where"); $c->execute($args); $total = (int)$c->fetchColumn();
$st = $pdo->prepare("SELECT n.*, t.transaction_ref, u.full_name, u.phone_number FROM notifications n
    JOIN transactions t ON t.transaction_id = n.transaction_id JOIN accounts a ON a.account_id = t.account_id JOIN users u ON u.user_id = a.user_id
    $where ORDER BY n.notification_id DESC LIMIT $per OFFSET " . (($page - 1) * $per));
$st->execute($args); $rows = $st->fetchAll();

page_header('Notification delivery monitor', 'admin', 'delivery');
?>
<div class="card filters">
  <a class="btn small <?= $status === '' ? '' : 'ghost' ?>" href="?">All</a>
  <?php foreach ($counts as $k => $n): ?><a class="btn small <?= $status === $k ? '' : 'ghost' ?>" href="?status=<?= $k ?>"><?= ucfirst($k) ?> (<?= $n ?>)</a><?php endforeach; ?>
  <?php if (SMS_MODE === 'simulator'): ?>
    <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="outage">
      <button class="btn small <?= sms_outage_active() ? 'danger' : 'ghost' ?>" name="state" value="<?= sms_outage_active() ? 'off' : 'on' ?>">
        Simulated gateway outage: <?= sms_outage_active() ? 'ON (click to switch off)' : 'OFF (click to test failures)' ?></button></form>
  <?php endif; ?>
</div>
<div class="card"><div class="scroll"><table>
  <tr><th>Time</th><th>Customer</th><th>Reference</th><th>Channel</th><th>Status</th><th>Retries</th><th>Action</th></tr>
  <?php foreach ($rows as $n): ?>
    <tr><td><?= h($n['created_at']) ?></td><td><?= h($n['full_name']) ?><br><small><?= h($n['phone_number']) ?></small></td><td><?= h($n['transaction_ref']) ?></td>
      <td><?= h($n['channel']) ?></td><td><?= status_badge($n['status']) ?></td><td><?= (int)$n['retry_count'] ?></td>
      <td><?php if ($n['status'] !== 'sent'): ?>
        <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="retry"><input type="hidden" name="notification_id" value="<?= (int)$n['notification_id'] ?>">
        <button class="btn small" type="submit">Retry</button></form><?php else: ?><span class="muted">Sent</span><?php endif; ?></td></tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="7" class="muted">No notifications.</td></tr><?php endif; ?>
</table></div><?= pagination($total, $per, $page) ?></div>
<?php page_footer();
