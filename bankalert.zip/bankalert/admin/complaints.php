<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
$admin = require_login(['admin']);
$pdo = db();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_check()) {
    $id = (int)($_POST['complaint_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    $resp = trim((string)($_POST['response'] ?? ''));
    if ($id && in_array($status, ['open', 'in progress', 'resolved'], true) && mb_strlen($resp) <= 1000) {
        $pdo->prepare('UPDATE complaints SET status = ?, admin_response = ? WHERE complaint_id = ?')->execute([$status, $resp, $id]);
        audit((int)$admin['user_id'], 'complaint_updated', "complaint $id => $status");
        flash('success', 'Complaint updated.');
    }
    redirect('admin/complaints.php?id=' . $id);
}
$list = $pdo->query('SELECT c.*, u.full_name FROM complaints c JOIN users u ON u.user_id = c.user_id ORDER BY (c.status = \'resolved\'), c.complaint_id DESC')->fetchAll();
$selId = (int)($_GET['id'] ?? ($list[0]['complaint_id'] ?? 0));
$sel = null;
if ($selId) {
    $st = $pdo->prepare('SELECT c.*, u.full_name, u.phone_number, t.transaction_ref, n.status AS nstatus, n.message FROM complaints c
        JOIN users u ON u.user_id = c.user_id LEFT JOIN transactions t ON t.transaction_id = c.transaction_id
        LEFT JOIN notifications n ON n.transaction_id = c.transaction_id WHERE c.complaint_id = ?');
    $st->execute([$selId]); $sel = $st->fetch() ?: null;
}
page_header('Notification complaints', 'admin', 'complaints');
?>
<div class="grid">
  <div class="card"><h2>Complaints</h2>
    <?php foreach ($list as $c): ?>
      <a class="note link <?= $c['complaint_id'] == $selId ? 'sel' : '' ?>" href="?id=<?= (int)$c['complaint_id'] ?>">
        <?= status_badge($c['status']) ?> <strong><?= h($c['full_name']) ?></strong> &middot; <?= h(ucfirst($c['issue_type'])) ?><br><small><?= h($c['created_at']) ?></small></a>
    <?php endforeach; ?>
    <?php if (!$list): ?><p class="muted">No complaints received.</p><?php endif; ?>
  </div>
  <div class="card"><h2>Details</h2>
  <?php if ($sel): ?>
    <p><b><?= h($sel['full_name']) ?></b> (<?= h($sel['phone_number']) ?>)<br>Problem: <b><?= h(ucfirst($sel['issue_type'])) ?></b>
      <?php if ($sel['transaction_ref']): ?><br>Transaction: <?= h($sel['transaction_ref']) ?> &middot; notification <?= $sel['nstatus'] ? status_badge($sel['nstatus']) : 'none' ?><?php endif; ?></p>
    <p class="note"><?= h($sel['description']) ?></p>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="complaint_id" value="<?= (int)$sel['complaint_id'] ?>">
      <label>Response to the customer<textarea name="response" rows="4" maxlength="1000"><?= h($sel['admin_response']) ?></textarea></label>
      <label>Status <select name="status"><?php foreach (['open', 'in progress', 'resolved'] as $s): ?><option <?= $sel['status'] === $s ? 'selected' : '' ?>><?= h($s) ?></option><?php endforeach; ?></select></label>
      <button class="btn" type="submit">Save response</button></form>
  <?php else: ?><p class="muted">Select a complaint.</p><?php endif; ?>
  </div>
</div>
<?php page_footer();
