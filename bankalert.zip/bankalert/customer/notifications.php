<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
$user = require_login(['customer']);
$acc  = customer_account((int)$user['user_id']);
$per = 10; $page = page_number();
$c = db()->prepare('SELECT COUNT(*) FROM notifications n JOIN transactions t ON t.transaction_id = n.transaction_id WHERE t.account_id = ?');
$c->execute([$acc['account_id']]);
$total = (int)$c->fetchColumn();
$st = db()->prepare('SELECT n.*, t.transaction_ref, t.transaction_id FROM notifications n JOIN transactions t ON t.transaction_id = n.transaction_id
                     WHERE t.account_id = ? ORDER BY n.notification_id DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per));
$st->execute([$acc['account_id']]);
$rows = $st->fetchAll();

page_header('Notification history', 'customer', 'notifications');
?>
<div class="card">
  <p>Missing, late, repeated or wrong message? <a class="btn small" href="<?= h(url('customer/complaint.php')) ?>">Report a problem</a></p>
  <div class="scroll"><table>
    <tr><th>Time</th><th>Message</th><th>Channel</th><th>Status</th></tr>
    <?php foreach ($rows as $n): ?>
      <tr><td><?= h($n['sent_at'] ?? $n['created_at']) ?></td><td><?= h($n['message']) ?></td><td><?= h($n['channel']) ?></td><td><?= status_badge($n['status']) ?></td></tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="4" class="muted">No notifications yet.</td></tr><?php endif; ?>
  </table></div><?= pagination($total, $per, $page) ?>
</div>
<?php page_footer();
