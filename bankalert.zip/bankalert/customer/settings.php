<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
$user = require_login(['customer']);
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pref  = $_POST['pref'] ?? '';
    $phone = normalise_phone((string)($_POST['phone'] ?? ''));
    if (!csrf_check()) { $error = 'Session expired. Please try again.'; }
    elseif (!in_array($pref, ['sms', 'push', 'both'], true)) { $error = 'Choose how you want to receive alerts.'; }
    elseif (!$phone) { $error = 'Enter a valid Kenyan mobile number, e.g. 0712345678.'; }
    else {
        $st = db()->prepare('UPDATE users SET notify_preference = ?, phone_number = ? WHERE user_id = ?');
        $st->execute([$pref, $phone, $user['user_id']]);
        audit((int)$user['user_id'], 'settings_changed', "channel $pref");
        flash('success', 'Notification settings saved.');
        redirect('customer/settings.php');
    }
}
$acc = customer_account((int)$user['user_id']);
page_header('Notification settings', 'customer', 'settings');
if ($error) { echo '<div class="alert error">' . h($error) . '</div>'; }
?>
<form method="post" class="card narrow">
  <?= csrf_field() ?>
  <label>Receive alerts by
    <select name="pref">
      <?php foreach (['sms' => 'SMS', 'push' => 'Push notification', 'both' => 'Both SMS and push'] as $k => $v): ?>
        <option value="<?= $k ?>" <?= $user['notify_preference'] === $k ? 'selected' : '' ?>><?= $v ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label>Phone number for SMS
    <input type="text" name="phone" required value="<?= h($_POST['phone'] ?? $user['phone_number']) ?>">
  </label>
  <button class="btn" type="submit">Save settings</button>
  <h3>Sample message</h3>
  <p class="note"><?= h(BANK_NAME) ?>: Deposit of KES 5,000.00 on A/C <?= h(mask_account($acc['account_number'])) ?> at 07 Nov 2026 14:32. New balance KES 17,500.00. Ref TX2611071432AB12</p>
</form>
<?php page_footer();
