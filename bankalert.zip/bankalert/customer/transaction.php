<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/transaction.php';
$user = require_login(['customer']);
$acc  = customer_account((int)$user['user_id']);
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        $error = 'Session expired. Please try again.';
    } else {
        $ref = (string)($_POST['ref'] ?? '');
        $res = process_transaction(db(), $user, (string)($_POST['type'] ?? ''), (string)($_POST['amount'] ?? ''),
                                   (string)($_POST['to_account'] ?? ''), $ref, (string)($_POST['pin'] ?? ''));
        if ($res['ok']) {
            $msg = 'Transaction successful. New balance KES ' . money($res['balance']) . '. ';
            $msg .= $res['notification'] === 'sent' ? 'Your notification was sent.'
                  : ($res['notification'] === 'failed' ? 'The notification could not be delivered yet; it is recorded for retry.' : '');
            flash($res['notification'] === 'failed' ? 'warn' : 'success', $msg);
            redirect('customer/dashboard.php');          // redirect after saving: a refresh cannot repeat the form
        }
        $error = $res['message'];
    }
}

// The reference is generated when the form is shown, so a repeated submission carries the same reference.
$ref = ($_SERVER['REQUEST_METHOD'] === 'POST' && valid_ref((string)($_POST['ref'] ?? ''))) ? $_POST['ref'] : generate_ref();
$type = $_POST['type'] ?? ($_GET['type'] ?? 'deposit');
if (!in_array($type, ['deposit', 'withdrawal', 'transfer'], true)) { $type = 'deposit'; }

page_header('Make a transaction', 'customer', 'transaction');
if ($error) { echo '<div class="alert error">' . h($error) . '</div>'; }
?>
<form method="post" class="card narrow" id="txnform" autocomplete="off">
  <?= csrf_field() ?>
  <input type="hidden" name="ref" value="<?= h($ref) ?>">
  <label>Transaction type
    <select name="type" id="type">
      <?php foreach (['deposit' => 'Deposit', 'withdrawal' => 'Withdrawal', 'transfer' => 'Transfer'] as $k => $v): ?>
        <option value="<?= $k ?>" <?= $type === $k ? 'selected' : '' ?>><?= $v ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label>Amount (KES)
    <input type="text" inputmode="decimal" name="amount" required value="<?= h($_POST['amount'] ?? '') ?>">
  </label>
  <label id="to-wrap">Receiving account number
    <input type="text" inputmode="numeric" name="to_account" value="<?= h($_POST['to_account'] ?? '') ?>">
  </label>
  <label>Confirm with your PIN
    <input type="password" name="pin" required>
  </label>
  <button class="btn" type="submit" data-once>Confirm transaction</button>
  <p class="muted">Current balance: KES <?= h(money($acc['balance'])) ?>. The new balance will be sent to you as a notification.</p>
</form>
<?php page_footer();
