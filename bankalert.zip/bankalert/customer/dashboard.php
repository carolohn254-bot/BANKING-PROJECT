<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
$user = require_login(['customer']);
$acc  = customer_account((int)$user['user_id']);
$pdo  = db();

$st = $pdo->prepare('SELECT * FROM transactions WHERE account_id = ? ORDER BY transaction_id DESC LIMIT 5');
$st->execute([$acc['account_id']]);
$recent = $st->fetchAll();

$st = $pdo->prepare('SELECT n.*, t.transaction_ref FROM notifications n JOIN transactions t ON t.transaction_id = n.transaction_id
                     WHERE t.account_id = ? ORDER BY n.notification_id DESC LIMIT 5');
$st->execute([$acc['account_id']]);
$notes = $st->fetchAll();

page_header('Dashboard', 'customer', 'dashboard');
?>
<div class="grid">
  <div class="card balance">
    <div class="muted">Available balance &middot; A/C <?= h(mask_account($acc['account_number'])) ?></div>
    <div class="big">KES <span id="bal" data-poll="<?= h(url('api/balance.php')) ?>"><?= h(money($acc['balance'])) ?></span></div>
    <div class="actions">
      <a class="btn" href="<?= h(url('customer/transaction.php?type=deposit')) ?>">Deposit</a>
      <a class="btn" href="<?= h(url('customer/transaction.php?type=withdrawal')) ?>">Withdraw</a>
      <a class="btn" href="<?= h(url('customer/transaction.php?type=transfer')) ?>">Transfer</a>
    </div>
    <div id="live" class="alert info" hidden></div>
  </div>
  <div class="card">
    <h2>Latest notifications</h2>
    <?php if (!$notes): ?><p class="muted">No notifications yet.</p><?php endif; ?>
    <?php foreach ($notes as $n): ?>
      <div class="note"><?= status_badge($n['status']) ?> <small><?= h($n['channel']) ?></small><br><?= h($n['message']) ?></div>
    <?php endforeach; ?>
  </div>
</div>
<div class="card">
  <h2>Recent transactions</h2>
  <div class="scroll"><table>
    <tr><th>Date</th><th>Reference</th><th>Type</th><th class="r">Amount</th><th class="r">Balance after</th></tr>
    <?php foreach ($recent as $t): ?>
      <tr><td><?= h(date('d M H:i', strtotime($t['created_at']))) ?></td><td><?= h($t['transaction_ref']) ?></td>
          <td><?= h(ucfirst($t['type'])) ?> (<?= h($t['direction']) ?>)</td>
          <td class="r <?= $t['direction'] === 'credit' ? 'pos' : 'neg' ?>"><?= $t['direction'] === 'credit' ? '+' : '-' ?><?= h(money($t['amount'])) ?></td>
          <td class="r"><?= h(money($t['balance_after'])) ?></td></tr>
    <?php endforeach; ?>
    <?php if (!$recent): ?><tr><td colspan="5" class="muted">No transactions yet.</td></tr><?php endif; ?>
  </table></div>
</div>
<?php page_footer();
