<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
$user = require_login(['customer']);
$acc  = customer_account((int)$user['user_id']);
$pdo = db();
$types = ['missing', 'delayed', 'duplicate', 'incorrect balance'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tid = (int)($_POST['transaction_id'] ?? 0);
    $issue = $_POST['issue_type'] ?? '';
    $desc = trim((string)($_POST['description'] ?? ''));
    if (!csrf_check()) { $error = 'Session expired. Please try again.'; }
    elseif (!in_array($issue, $types, true)) { $error = 'Choose the type of problem.'; }
    elseif ($desc === '' || mb_strlen($desc) > 1000) { $error = 'Describe the problem (up to 1000 characters).'; }
    else {
        if ($tid) {                                              // the transaction must belong to this customer
            $chk = $pdo->prepare('SELECT 1 FROM transactions WHERE transaction_id = ? AND account_id = ?');
            $chk->execute([$tid, $acc['account_id']]);
            if (!$chk->fetch()) { $tid = 0; }
        }
        $st = $pdo->prepare("INSERT INTO complaints (user_id, transaction_id, issue_type, description, status) VALUES (?, ?, ?, ?, 'open')");
        $st->execute([$user['user_id'], $tid ?: null, $issue, $desc]);
        audit((int)$user['user_id'], 'complaint_submitted', $issue);
        flash('success', 'Your complaint was sent to the bank. You will see the response on this page.');
        redirect('customer/complaint.php');
    }
}
$st = $pdo->prepare('SELECT transaction_id, transaction_ref, type, amount, created_at FROM transactions WHERE account_id = ? ORDER BY transaction_id DESC LIMIT 30');
$st->execute([$acc['account_id']]);
$txns = $st->fetchAll();
$mine = $pdo->prepare('SELECT c.*, t.transaction_ref FROM complaints c LEFT JOIN transactions t ON t.transaction_id = c.transaction_id WHERE c.user_id = ? ORDER BY c.complaint_id DESC');
$mine->execute([$user['user_id']]);
$list = $mine->fetchAll();

page_header('Report a notification problem', 'customer', 'complaint');
if ($error) { echo '<div class="alert error">' . h($error) . '</div>'; }
?>
<form method="post" class="card narrow">
  <?= csrf_field() ?>
  <label>Transaction concerned
    <select name="transaction_id"><option value="0">Not sure / none</option>
      <?php foreach ($txns as $t): ?>
        <option value="<?= (int)$t['transaction_id'] ?>"><?= h($t['transaction_ref'] . ' - ' . ucfirst($t['type']) . ' KES ' . money($t['amount'])) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label>Type of problem
    <select name="issue_type"><?php foreach ($types as $t): ?><option value="<?= h($t) ?>"><?= h(ucfirst($t)) ?></option><?php endforeach; ?></select>
  </label>
  <label>Describe the problem
    <textarea name="description" rows="4" maxlength="1000" required><?= h($_POST['description'] ?? '') ?></textarea>
  </label>
  <button class="btn" type="submit" data-once>Send complaint</button>
</form>
<div class="card"><h2>My complaints</h2>
  <?php foreach ($list as $c): ?>
    <div class="note"><?= status_badge($c['status']) ?> <strong><?= h(ucfirst($c['issue_type'])) ?></strong>
      <small><?= h($c['created_at']) ?><?= $c['transaction_ref'] ? ' &middot; ' . h($c['transaction_ref']) : '' ?></small>
      <br><?= h($c['description']) ?>
      <?php if ($c['admin_response']): ?><br><em>Bank response: <?= h($c['admin_response']) ?></em><?php endif; ?></div>
  <?php endforeach; ?>
  <?php if (!$list): ?><p class="muted">You have not submitted any complaints.</p><?php endif; ?>
</div>
<?php page_footer();
