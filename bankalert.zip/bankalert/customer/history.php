<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
$user = require_login(['customer']);
$acc  = customer_account((int)$user['user_id']);

$from = valid_date($_GET['from'] ?? null); $to = valid_date($_GET['to'] ?? null);
$type = in_array($_GET['type'] ?? '', ['deposit', 'withdrawal', 'transfer'], true) ? $_GET['type'] : '';
$where = 'account_id = ?'; $args = [$acc['account_id']];
if ($from) { $where .= ' AND created_at >= ?'; $args[] = $from . ' 00:00:00'; }
if ($to)   { $where .= ' AND created_at <= ?'; $args[] = $to . ' 23:59:59'; }
if ($type) { $where .= ' AND type = ?'; $args[] = $type; }

$per = 10; $page = page_number();
$c = db()->prepare("SELECT COUNT(*) FROM transactions WHERE $where"); $c->execute($args);
$total = (int)$c->fetchColumn();
$st = db()->prepare("SELECT * FROM transactions WHERE $where ORDER BY transaction_id DESC LIMIT $per OFFSET " . (($page - 1) * $per));
$st->execute($args);
$rows = $st->fetchAll();

page_header('Transaction history', 'customer', 'history');
?>
<form method="get" class="card filters">
  <label>From <input type="date" name="from" value="<?= h($from) ?>"></label>
  <label>To <input type="date" name="to" value="<?= h($to) ?>"></label>
  <label>Type <select name="type"><option value="">All</option>
    <?php foreach (['deposit', 'withdrawal', 'transfer'] as $t): ?><option value="<?= $t ?>" <?= $type === $t ? 'selected' : '' ?>><?= ucfirst($t) ?></option><?php endforeach; ?>
  </select></label>
  <button class="btn" type="submit">Filter</button>
</form>
<div class="card"><div class="scroll"><table>
  <tr><th>Date and time</th><th>Reference</th><th>Type</th><th class="r">Amount</th><th class="r">Balance after</th></tr>
  <?php foreach ($rows as $t): ?>
    <tr><td><?= h($t['created_at']) ?></td><td><?= h($t['transaction_ref']) ?></td><td><?= h(ucfirst($t['type'])) ?> (<?= h($t['direction']) ?>)</td>
        <td class="r <?= $t['direction'] === 'credit' ? 'pos' : 'neg' ?>"><?= $t['direction'] === 'credit' ? '+' : '-' ?><?= h(money($t['amount'])) ?></td>
        <td class="r"><?= h(money($t['balance_after'])) ?></td></tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="5" class="muted">No transactions found.</td></tr><?php endif; ?>
</table></div><?= pagination($total, $per, $page) ?></div>
<?php page_footer();
