<?php
/**
 * Central configuration: database connection, application settings and SMS gateway credentials.
 * Change the values below to match the server the system is installed on.
 */

// ---- Database (XAMPP defaults) ----
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'bank_notify');
define('DB_USER', 'root');
define('DB_PASS', '');

// ---- Application ----
define('APP_NAME', 'Real-Time Mobile Banking');
define('BANK_NAME', 'ZetechBank');
define('SESSION_TIMEOUT', 900);          // seconds of inactivity before automatic logout
define('DEBUG', false);                  // set true only on the development computer
define('BASE_URL_OVERRIDE', '');         // leave empty: the folder URL is detected automatically

// ---- SMS gateway ----
// 'simulator'      : messages are written to storage/sms_outbox.log (no real SMS is sent)
// 'africastalking' : messages are sent through the Africa's Talking sandbox/live API
define('SMS_MODE', 'simulator');
define('AT_USERNAME', 'sandbox');
define('AT_API_KEY', '');                // keep the key here, never inside the pages
define('AT_SENDER', '');                 // optional sender id

date_default_timezone_set('Africa/Nairobi');   // East Africa Time
error_reporting(E_ALL);
ini_set('display_errors', DEBUG ? '1' : '0');
ini_set('log_errors', '1');

/** Folder of the system as seen from the browser, e.g. "/bankalert" (works on any device). */
function detect_base_url(): string
{
    if (BASE_URL_OVERRIDE !== '') {
        return rtrim(BASE_URL_OVERRIDE, '/');
    }
    $root = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '/') : '';
    $app  = str_replace('\\', '/', dirname(__DIR__));
    if ($root !== '' && stripos($app, $root) === 0) {
        return substr($app, strlen($root));
    }
    return '';
}
define('BASE_URL', detect_base_url());

/** One shared PDO connection (PHP Data Objects) that reports errors as exceptions. */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        $pdo->exec("SET time_zone = '+03:00'");
    }
    return $pdo;
}
