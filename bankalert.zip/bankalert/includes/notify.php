<?php
/** Notification module: duplicate check, message composition, sending, saving the status, and safe retry. */
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/sms.php';

function compose_message(array $t, string $accountNumber): string
{
    $kind = $t['type'] === 'transfer' ? ($t['direction'] === 'credit' ? 'Transfer received' : 'Transfer sent')
          : ($t['type'] === 'deposit' ? 'Deposit' : 'Withdrawal');
    $other = ($t['type'] === 'transfer' && $t['counterparty_account'])
        ? ($t['direction'] === 'credit' ? ' from A/C ' : ' to A/C ') . mask_account($t['counterparty_account']) : '';
    return BANK_NAME . ': ' . $kind . ' of KES ' . money($t['amount']) . $other
        . ' on A/C ' . mask_account($accountNumber) . ' at ' . date('d M Y H:i', strtotime($t['created_at']))
        . '. New balance KES ' . money($t['balance_after']) . '. Ref ' . $t['transaction_ref'];
}

/** Delivers a message over the customer's chosen channel(s). Returns ['ok' => bool, 'channel' => string]. */
function deliver(string $preference, string $phone, string $message): array
{
    $channel = $preference === 'both' ? 'SMS+push' : ($preference === 'push' ? 'push' : 'SMS');
    $ok = true;
    if ($preference !== 'push') { $ok = send_sms($phone, $message)['ok']; }
    // Push notifications are shown inside the web app (dashboard banner), so they are available once the record exists.
    return ['ok' => $ok, 'channel' => $channel];
}

/**
 * Called only AFTER the transaction has been committed.
 * Returns 'sent', 'failed' or 'duplicate'. A failure never cancels the money movement.
 */
function notify_transaction(PDO $pdo, int $transactionId): string
{
    $st = $pdo->prepare('SELECT notification_id FROM notifications WHERE transaction_id = ?');
    $st->execute([$transactionId]);
    if ($st->fetch()) { return 'duplicate'; }                       // already notified: send nothing

    $st = $pdo->prepare('SELECT t.*, a.account_number, u.user_id, u.phone_number, u.notify_preference
                         FROM transactions t JOIN accounts a ON a.account_id = t.account_id
                         JOIN users u ON u.user_id = a.user_id WHERE t.transaction_id = ?');
    $st->execute([$transactionId]);
    $t = $st->fetch();
    if (!$t) { return 'failed'; }

    $message = compose_message($t, $t['account_number']);
    $channel = $t['notify_preference'] === 'both' ? 'SMS+push' : ($t['notify_preference'] === 'push' ? 'push' : 'SMS');
    try {
        $ins = $pdo->prepare("INSERT INTO notifications (transaction_id, message, channel, status) VALUES (?, ?, ?, 'pending')");
        $ins->execute([$transactionId, $message, $channel]);
    } catch (PDOException $e) {
        if ($e->errorInfo[1] === 1062) { return 'duplicate'; }       // unique key blocked a second record
        throw $e;
    }
    $nid = (int)$pdo->lastInsertId();

    $res = deliver($t['notify_preference'], $t['phone_number'], $message);
    $status = $res['ok'] ? 'sent' : 'failed';
    $up = $pdo->prepare("UPDATE notifications SET status = ?, sent_at = IF(? = 'sent', NOW(), NULL) WHERE notification_id = ? AND status = 'pending'");
    $up->execute([$status, $status, $nid]);
    audit((int)$t['user_id'], 'notification_' . $status, 'ref ' . $t['transaction_ref']);
    return $status;
}

/** Administrator retry. A notification that was already sent can never be sent again. Returns [ok, message]. */
function retry_notification(PDO $pdo, int $notificationId, int $adminId): array
{
    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare('SELECT n.*, u.phone_number, u.notify_preference
                             FROM notifications n JOIN transactions t ON t.transaction_id = n.transaction_id
                             JOIN accounts a ON a.account_id = t.account_id JOIN users u ON u.user_id = a.user_id
                             WHERE n.notification_id = ? FOR UPDATE');
        $st->execute([$notificationId]);
        $n = $st->fetch();
        if (!$n) { $pdo->rollBack(); return [false, 'Notification not found.']; }
        if ($n['status'] === 'sent') { $pdo->rollBack(); return [false, 'This notification was already sent and cannot be sent again.']; }

        $res = deliver($n['notify_preference'], $n['phone_number'], $n['message']);
        $status = $res['ok'] ? 'sent' : 'failed';
        // Status is checked again inside the UPDATE statement as well.
        $up = $pdo->prepare("UPDATE notifications SET status = ?, retry_count = retry_count + 1,
                             sent_at = IF(? = 'sent', NOW(), sent_at) WHERE notification_id = ? AND status IN ('failed','pending')");
        $up->execute([$status, $status, $notificationId]);
        $pdo->commit();
        audit($adminId, 'notification_retry', 'notification ' . $notificationId . ' => ' . $status);
        return [$res['ok'], $res['ok'] ? 'Notification sent successfully.' : 'Retry failed. The gateway did not confirm delivery.'];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        error_log('retry failed: ' . $e->getMessage());
        return [false, 'Could not retry the notification.'];
    }
}
