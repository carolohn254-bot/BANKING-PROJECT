<?php
/**
 * SMS gateway connection. SMS_MODE (config/database.php) selects the simulator or Africa's Talking.
 * The outage switch (storage/sms_outage.flag) lets administrators/testers simulate a gateway failure.
 */
require_once __DIR__ . '/../config/database.php';

function sms_outage_file(): string { return __DIR__ . '/../storage/sms_outage.flag'; }
function sms_outage_active(): bool { return is_file(sms_outage_file()); }
function sms_set_outage(bool $on): void
{
    if ($on) { @file_put_contents(sms_outage_file(), date('c')); }
    elseif (is_file(sms_outage_file())) { @unlink(sms_outage_file()); }
}

/** Sends one SMS. Returns ['ok' => bool, 'detail' => string]. Never throws. */
function send_sms(string $phone, string $message): array
{
    if (sms_outage_active()) { return ['ok' => false, 'detail' => 'gateway outage switch is ON']; }

    if (SMS_MODE === 'africastalking') {
        if (!function_exists('curl_init') || AT_API_KEY === '') { return ['ok' => false, 'detail' => 'gateway not configured']; }
        $endpoint = AT_USERNAME === 'sandbox'
            ? 'https://api.sandbox.africastalking.com/version1/messaging'
            : 'https://api.africastalking.com/version1/messaging';
        $fields = ['username' => AT_USERNAME, 'to' => $phone, 'message' => $message];
        if (AT_SENDER !== '') { $fields['from'] = AT_SENDER; }
        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query($fields),
            CURLOPT_HTTPHEADER => ['apiKey: ' . AT_API_KEY, 'Accept: application/json'],
            CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4,
        ]);
        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        if ($body === false) { return ['ok' => false, 'detail' => 'gateway unreachable: ' . $err]; }
        $json = json_decode($body, true);
        $status = $json['SMSMessageData']['Recipients'][0]['status'] ?? '';
        return ($code === 201 && $status === 'Success')
            ? ['ok' => true, 'detail' => 'delivered to gateway']
            : ['ok' => false, 'detail' => 'gateway replied HTTP ' . $code . ' ' . $status];
    }

    // Simulator: append to an outbox log so messages can be inspected without real SMS.
    $line = date('Y-m-d H:i:s') . " | $phone | $message" . PHP_EOL;
    $written = @file_put_contents(__DIR__ . '/../storage/sms_outbox.log', $line, FILE_APPEND | LOCK_EX);
    return $written === false ? ['ok' => false, 'detail' => 'cannot write outbox'] : ['ok' => true, 'detail' => 'simulated'];
}
