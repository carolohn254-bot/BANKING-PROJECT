<?php
require_once __DIR__ . '/../config/database.php';

function h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function url(string $path = ''): string { return BASE_URL . '/' . ltrim($path, '/'); }
function redirect(string $path): void { header('Location: ' . url($path)); exit; }
function money($n): string { return number_format((float)$n, 2); }
function mask_account(string $acc): string { return '****' . substr($acc, -4); }

// ---- Flash messages (shown once after a redirect) ----
function flash(string $type, string $message): void { $_SESSION['flash'][] = ['type' => $type, 'msg' => $message]; }
function flash_pull(): array { $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f; }

// ---- CSRF protection for every form ----
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">'; }
function csrf_check(): bool
{
    return isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], (string)$_POST['csrf']);
}

// ---- Validation helpers ----
/** Accepts 07xx / 01xx / 2547xx / +2547xx numbers and returns +2547XXXXXXXX, or null when invalid. */
function normalise_phone(string $p): ?string
{
    $p = preg_replace('/[\s\-]/', '', $p);
    if (preg_match('/^(?:\+254|254|0)([17]\d{8})$/', $p, $m)) { return '+254' . $m[1]; }
    return null;
}
/** Returns the amount in cents, or null when the amount is not a valid positive money value. */
function parse_amount(string $a): ?int
{
    $a = str_replace(',', '', trim($a));
    if (!preg_match('/^\d{1,9}(\.\d{1,2})?$/', $a)) { return null; }
    $cents = (int) round(((float)$a) * 100);
    return ($cents > 0 && $cents <= 100000000) ? $cents : null;
}
function cents_to_decimal(int $c): string { return number_format($c / 100, 2, '.', ''); }
function decimal_to_cents($d): int { return (int) round(((float)$d) * 100); }

/** Unique transaction reference: date + time + random code (fits VARCHAR(30)). */
function generate_ref(): string { return 'TX' . date('ymdHis') . strtoupper(bin2hex(random_bytes(2))); }
function valid_ref(string $r): bool { return (bool) preg_match('/^TX\d{12}[A-F0-9]{4}$/', $r); }

// ---- Audit log ----
function audit(?int $userId, string $action, string $details = ''): void
{
    try {
        $st = db()->prepare('INSERT INTO audit_logs (user_id, action, details) VALUES (?, ?, ?)');
        $st->execute([$userId, $action, $details]);
    } catch (Throwable $e) { error_log('audit failed: ' . $e->getMessage()); }
}

function status_badge(string $s): string
{
    $map = ['sent' => 'ok', 'active' => 'ok', 'resolved' => 'ok', 'failed' => 'bad', 'suspended' => 'bad',
            'open' => 'bad', 'pending' => 'warn', 'in progress' => 'warn'];
    return '<span class="badge ' . ($map[$s] ?? '') . '">' . h(ucfirst($s)) . '</span>';
}

/** Simple pagination links keeping the current filters. */
function pagination(int $total, int $per, int $page): string
{
    $pages = (int) ceil($total / $per);
    if ($pages <= 1) { return ''; }
    $out = '<div class="pager">';
    for ($i = 1; $i <= $pages; $i++) {
        $q = array_merge($_GET, ['page' => $i]);
        $out .= '<a class="' . ($i === $page ? 'cur' : '') . '" href="?' . h(http_build_query($q)) . '">' . $i . '</a>';
    }
    return $out . '</div>';
}
function page_number(): int { return max(1, (int)($_GET['page'] ?? 1)); }
function valid_date(?string $d): ?string
{
    if (!$d) { return null; }
    $x = DateTime::createFromFormat('Y-m-d', $d);
    return ($x && $x->format('Y-m-d') === $d) ? $d : null;
}
