<?php
/** Transaction module: validation, PIN check, ONE database transaction with row locking, rollback, notification call. */
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/notify.php';

/**
 * @return array ['ok'=>bool, 'message'=>string, 'balance'=>?string, 'notification'=>?string]
 */
function process_transaction(PDO $pdo, array $user, string $type, string $amountInput, string $toAccount, string $ref, string $pin): array
{
    $fail = fn(string $m) => ['ok' => false, 'message' => $m, 'balance' => null, 'notification' => null];

    if (!in_array($type, ['deposit', 'withdrawal', 'transfer'], true)) { return $fail('Choose a valid transaction type.'); }
    $cents = parse_amount($amountInput);
    if ($cents === null) { return $fail('Enter a valid amount greater than zero (maximum KES 1,000,000).'); }
    if (!valid_ref($ref)) { return $fail('Invalid form. Please reload the page and try again.'); }
    if (!password_verify($pin, $user['password_hash'])) {
        audit((int)$user['user_id'], 'transaction_rejected', 'wrong PIN');
        return $fail('Wrong PIN. The transaction was not made.');
    }
    $toAccount = trim($toAccount);
    if ($type === 'transfer' && !preg_match('/^\d{6,20}$/', $toAccount)) { return $fail('Enter the receiving account number.'); }

    $mine = customer_account((int)$user['user_id']);
    if (!$mine) { return $fail('You do not have an account.'); }

    // A repeated submission carries the same reference: stop before touching any balance.
    $dup = $pdo->prepare('SELECT 1 FROM transactions WHERE transaction_ref = ?');
    $dup->execute([$ref]);
    if ($dup->fetch()) { return $fail('This transaction was already processed. Nothing was repeated.'); }

    $txnIds = [];
    try {
        $pdo->beginTransaction();

        // Lock the account row(s) in a fixed order so two requests cannot change a balance at the same moment.
        $ids = [(int)$mine['account_id']];
        $theirs = null;
        if ($type === 'transfer') {
            $st = $pdo->prepare('SELECT a.*, u.status FROM accounts a JOIN users u ON u.user_id = a.user_id WHERE a.account_number = ?');
            $st->execute([$toAccount]);
            $theirs = $st->fetch();
            if (!$theirs || $theirs['status'] !== 'active') { $pdo->rollBack(); return $fail('The receiving account does not exist or is not active.'); }
            if ((int)$theirs['account_id'] === (int)$mine['account_id']) { $pdo->rollBack(); return $fail('You cannot transfer to your own account.'); }
            $ids[] = (int)$theirs['account_id'];
        }
        sort($ids);
        $locked = [];
        foreach ($ids as $id) {
            $st = $pdo->prepare('SELECT account_id, account_number, balance FROM accounts WHERE account_id = ? FOR UPDATE');
            $st->execute([$id]);
            $locked[$id] = $st->fetch();
        }
        $myBal = decimal_to_cents($locked[(int)$mine['account_id']]['balance']);
        if ($type !== 'deposit' && $myBal < $cents) {
            $pdo->rollBack();
            audit((int)$user['user_id'], 'transaction_rejected', 'insufficient balance');
            return $fail('Insufficient balance for this transaction.');
        }

        $insT = $pdo->prepare('INSERT INTO transactions (transaction_ref, account_id, type, direction, amount, balance_after, counterparty_account)
                               VALUES (?, ?, ?, ?, ?, ?, ?)');
        $updB = $pdo->prepare('UPDATE accounts SET balance = ? WHERE account_id = ?');

        $direction = $type === 'deposit' ? 'credit' : 'debit';
        $newMy = $direction === 'credit' ? $myBal + $cents : $myBal - $cents;
        $insT->execute([$ref, $mine['account_id'], $type, $direction, cents_to_decimal($cents), cents_to_decimal($newMy),
                        $type === 'transfer' ? $theirs['account_number'] : null]);
        $txnIds[] = (int)$pdo->lastInsertId();
        $updB->execute([cents_to_decimal($newMy), $mine['account_id']]);

        if ($type === 'transfer') {                               // second linked record for the receiver
            $theirBal = decimal_to_cents($locked[(int)$theirs['account_id']]['balance']);
            $newTheir = $theirBal + $cents;
            $insT->execute([$ref . 'R', $theirs['account_id'], 'transfer', 'credit', cents_to_decimal($cents), cents_to_decimal($newTheir), $mine['account_number']]);
            $txnIds[] = (int)$pdo->lastInsertId();
            $updB->execute([cents_to_decimal($newTheir), $theirs['account_id']]);
        }
        $pdo->commit();                                           // balance + record saved together
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        if (($e->errorInfo[1] ?? 0) === 1062) { return $fail('This transaction was already processed. Nothing was repeated.'); }
        error_log('transaction failed: ' . $e->getMessage());
        return $fail('The transaction could not be completed. No money was moved.');
    }

    audit((int)$user['user_id'], 'transaction', "$type KES " . cents_to_decimal($cents) . " ref $ref");

    // Notification module runs only after the commit; its outcome never undoes the transaction.
    $notifyStatus = 'failed';
    foreach ($txnIds as $i => $tid) {
        try { $s = notify_transaction($pdo, $tid); } catch (Throwable $e) { error_log('notify error: ' . $e->getMessage()); $s = 'failed'; }
        if ($i === 0) { $notifyStatus = $s; }
    }
    return ['ok' => true, 'message' => 'Transaction successful.', 'balance' => cents_to_decimal($newMy), 'notification' => $notifyStatus];
}
