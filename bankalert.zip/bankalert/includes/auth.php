<?php
require_once __DIR__ . '/functions.php';

function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_name('BANKSESS');
        session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
        session_start();
    }
}

/** Checks the credentials, starts the session and returns [ok, message]. */
function login_user(string $username, string $password): array
{
    $pdo = db();
    // Block repeated guessing: 5 failed attempts for a username in 10 minutes.
    $st = $pdo->prepare("SELECT COUNT(*) FROM audit_logs WHERE action='login_failed' AND details=? AND created_at > (NOW() - INTERVAL 10 MINUTE)");
    $st->execute([$username]);
    if ((int)$st->fetchColumn() >= 5) { return [false, 'Too many failed attempts. Please wait 10 minutes and try again.']; }

    $st = $pdo->prepare('SELECT * FROM users WHERE username = ?');
    $st->execute([$username]);
    $user = $st->fetch();
    if (!$user || !password_verify($password, $user['password_hash'])) {
        audit($user['user_id'] ?? null, 'login_failed', $username);
        return [false, 'Wrong username or password / PIN.'];
    }
    if ($user['status'] !== 'active') {
        audit((int)$user['user_id'], 'login_refused', 'suspended account');
        return [false, 'Your account is suspended. Please contact the bank.'];
    }
    session_regenerate_id(true);                       // prevents session fixation
    $_SESSION['user_id']  = (int)$user['user_id'];
    $_SESSION['role']     = $user['role'];
    $_SESSION['name']     = $user['full_name'];
    $_SESSION['last_act'] = time();
    audit((int)$user['user_id'], 'login', $user['role']);
    return [true, ''];
}

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) { return null; }
    $st = db()->prepare('SELECT * FROM users WHERE user_id = ?');
    $st->execute([$_SESSION['user_id']]);
    return $st->fetch() ?: null;
}

function logout_user(string $reason = 'logout'): void
{
    if (!empty($_SESSION['user_id'])) { audit((int)$_SESSION['user_id'], $reason); }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 3600, $p['path'], $p['domain'] ?? '', false, true);
    }
    session_destroy();
}

/** Protects a page: login, inactivity timeout, live status check and role check. Returns the user row. */
function require_login(array $roles): array
{
    start_secure_session();
    if (empty($_SESSION['user_id'])) { redirect('index.php'); }
    if (time() - ($_SESSION['last_act'] ?? 0) > SESSION_TIMEOUT) {
        logout_user('session_timeout');
        start_secure_session();
        flash('error', 'You were logged out because of inactivity.');
        redirect('index.php');
    }
    $_SESSION['last_act'] = time();
    $user = current_user();
    if (!$user || $user['status'] !== 'active') {            // suspended while logged in
        logout_user('session_ended_suspended');
        start_secure_session();
        flash('error', 'Your account is not active.');
        redirect('index.php');
    }
    if (!in_array($user['role'], $roles, true)) {
        redirect($user['role'] === 'admin' ? 'admin/dashboard.php' : 'customer/dashboard.php');
    }
    return $user;
}

/** The customer's account row (one account per customer in this system). */
function customer_account(int $userId): ?array
{
    $st = db()->prepare('SELECT * FROM accounts WHERE user_id = ? ORDER BY account_id LIMIT 1');
    $st->execute([$userId]);
    return $st->fetch() ?: null;
}
