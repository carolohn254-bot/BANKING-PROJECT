<?php
require_once __DIR__ . '/functions.php';

function page_header(string $title, string $role = '', string $active = ''): void
{
    $customer = [
        'dashboard' => ['Dashboard', 'customer/dashboard.php'], 'transaction' => ['Make transaction', 'customer/transaction.php'],
        'history' => ['History', 'customer/history.php'], 'notifications' => ['Notifications', 'customer/notifications.php'],
        'settings' => ['Settings', 'customer/settings.php'], 'complaint' => ['Report problem', 'customer/complaint.php'],
    ];
    $admin = [
        'dashboard' => ['Dashboard', 'admin/dashboard.php'], 'customers' => ['Customers', 'admin/customers.php'],
        'transactions' => ['Transactions', 'admin/transactions.php'], 'delivery' => ['Delivery monitor', 'admin/delivery.php'],
        'complaints' => ['Complaints', 'admin/complaints.php'], 'reports' => ['Reports & audit log', 'admin/reports.php'],
    ];
    $menu = $role === 'admin' ? $admin : ($role === 'customer' ? $customer : []);
    ?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0b5d3b">
<title><?= h($title) ?> | <?= h(BANK_NAME) ?></title>
<link rel="stylesheet" href="<?= h(url('assets/css/style.css')) ?>">
</head>
<body class="<?= $role === 'admin' ? 'admin' : '' ?>">
<header class="top">
  <div class="brand"><?= h(BANK_NAME) ?> <small><?= $role === 'admin' ? 'Administrator' : 'Mobile Banking' ?></small></div>
  <?php if ($role): ?>
  <nav class="menu">
    <?php foreach ($menu as $key => [$label, $path]): ?>
      <a class="<?= $key === $active ? 'on' : '' ?>" href="<?= h(url($path)) ?>"><?= h($label) ?></a>
    <?php endforeach; ?>
    <a class="out" href="<?= h(url('logout.php')) ?>">Log out (<?= h($_SESSION['name'] ?? '') ?>)</a>
  </nav>
  <?php endif; ?>
</header>
<?php if ($role === 'admin'): ?>
<aside class="sidebar"><?php foreach ($menu as $key => [$label, $path]): ?>
  <a class="<?= $key === $active ? 'on' : '' ?>" href="<?= h(url($path)) ?>"><?= h($label) ?></a>
<?php endforeach; ?><a href="<?= h(url('logout.php')) ?>">Log out</a></aside>
<?php endif; ?>
<main class="wrap">
<?php foreach (flash_pull() as $f): ?>
  <div class="alert <?= h($f['type']) ?>"><?= h($f['msg']) ?></div>
<?php endforeach; ?>
<h1><?= h($title) ?></h1>
<?php
}

function page_footer(): void
{
    ?></main>
<footer class="foot"><?= h(APP_NAME) ?> &middot; simulated data only</footer>
<script src="<?= h(url('assets/js/app.js')) ?>"></script>
</body>
</html>
<?php
}
